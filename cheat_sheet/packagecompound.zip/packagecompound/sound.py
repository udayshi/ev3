import ev3dev.ev3 as ev3

def beep():
  ev3.Sound.beep().wait()