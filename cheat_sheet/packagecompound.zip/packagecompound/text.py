import ev3dev.ev3 as ev3
import time

def sayHello():
  print('Hello world')
  time.sleep(5)
